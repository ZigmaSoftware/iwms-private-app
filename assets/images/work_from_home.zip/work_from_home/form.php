<?php
// ─────────────────────────────────────────────
// Session
// ─────────────────────────────────────────────
$logged_staff_id = $_SESSION['staff_id']     ?? '';
$logged_user_id  = $_SESSION['sess_user_id'] ?? '';

// ─────────────────────────────────────────────
// NOTE: Approver redirect REMOVED.
// Reporting officers are also employees and must
// be able to submit their own WFH requests.
// Role-based split is handled in list.php (tabs).
// ─────────────────────────────────────────────

// ─────────────────────────────────────────────
// Defaults
// ─────────────────────────────────────────────
$unique_id_val     = '';
$wfh_date_val      = '';
$day_val           = '';
$remarks_val       = '';
$status_val        = 0;
$reject_reason_val = '';
$cancel_reason_val = '';
$is_update_mode    = !empty($_GET['unique_id']);
$edit_uid          = $is_update_mode ? $_GET['unique_id'] : '';

// ─────────────────────────────────────────────
// Auto-fetch logged-in staff info
// ─────────────────────────────────────────────
$emp_id = $logged_staff_id;

$staff_info         = staff_name_bp($emp_id);
$staff_name_display = $staff_info[0]['staff_name'] ?? '';

// ─────────────────────────────────────────────
// Get department & reporting officer
// FIX: staff_test.department stores department_creation.unique_id
//      Join on dc.unique_id = st.department (not via department_head)
// ─────────────────────────────────────────────
$reporting_officer_id    = '';
$department_display      = '';
$department_head_display = '';

$emp_esc  = addslashes($emp_id);
$info_sql = "
    SELECT
        st.reporting_officer,
        dc.department
    FROM staff_test st
    LEFT JOIN department_creation dc
        ON dc.unique_id  = st.department
        AND dc.is_delete = 0
    WHERE st.employee_id = '$emp_esc'
      AND st.is_delete   = 0
      AND st.is_active   = 1
    LIMIT 1
";
$info_res = $pdo->query($info_sql);

if ($info_res->status && !empty($info_res->data)) {
    $reporting_officer_id = $info_res->data[0]['reporting_officer'] ?? '';
    $department_display   = $info_res->data[0]['department']        ?? '';
}

// Resolve dept head display name
if ($reporting_officer_id) {
    $head_info               = staff_name_bp($reporting_officer_id);
    $department_head_display = $head_info[0]['staff_name'] ?? '';
}

// ─────────────────────────────────────────────
// Edit Mode
// ─────────────────────────────────────────────
if ($is_update_mode) {
    $rec = $pdo->select(
        ['work_from_home', [
            'unique_id', 'date', 'remarks',
            'status', 'reject_reason', 'cancel_reason', 'created_user_id'
        ]],
        ['unique_id' => $edit_uid, 'is_delete' => 0]
    );

    if ($rec->status && !empty($rec->data)) {
        $row = $rec->data[0];

        // Only original creator can edit
        if ($row['created_user_id'] !== $logged_user_id) {
            echo "<script>window.location.href='" . ($btn_cancel ?? '#') . "';</script>";
            return; // use return not exit — lets layout footer (Swal CDN) load
        }

        // ─────────────────────────────────────────────
        // FIX: Only Rejected status allows editing.
        // BEFORE: exit was used → layout footer never
        //         loaded → SweetAlert2 undefined at runtime.
        // NOW:    return from included file → layout
        //         footer loads → Swal works correctly.
        //
        // UPDATE: Cancelled (status 3) is also non-editable.
        // A WFH auto-cancelled because an Approved Leave now
        // covers the same date must not be re-submitted — the
        // leave is the source of truth for that date.
        // ─────────────────────────────────────────────
        if ((int)$row['status'] !== 2) {
            $list_url = addslashes($btn_cancel ?? '#');

            if ((int)$row['status'] === 3) {
                $not_editable_text = 'This WFH request was automatically cancelled because '
                    . 'an approved Leave already covers this date. It cannot be edited or re-submitted.';
            } else {
                $not_editable_text = 'WFH requests can only be edited when the status is Rejected.';
            }
            ?>
            <script>
            document.addEventListener('DOMContentLoaded', function () {
                Swal.fire({
                    icon:  'info',
                    title: 'Not Editable',
                    text:  <?= json_encode($not_editable_text) ?>
                }).then(function () {
                    window.location.href = '<?= $list_url ?>';
                });
            });
            </script>
            <?php
            return; // ← return (not exit) so SweetAlert2 CDN in footer loads
        }

        $unique_id_val     = $row['unique_id'];
        $wfh_date_val      = $row['date'];
        $day_val           = !empty($row['date']) ? date('l', strtotime($row['date'])) : '';
        $remarks_val       = $row['remarks']       ?? '';
        $status_val        = (int)$row['status'];
        $reject_reason_val = $row['reject_reason'] ?? '';
        $cancel_reason_val = $row['cancel_reason'] ?? '';
    }
}
?>

<style>
.wfh-readonly-field {
    background: #f8fafc !important;
    color: #64748b;
    font-weight: 500;
}
</style>

<div class="container-fluid py-4">
<div class="row g-4">

    <!-- ── Form ── -->
    <div class="col-12">
        <div class="card border-0 rounded-4 shadow-sm">
            <div class="card-body p-4">

                <h5 class="fw-semibold mb-4">
                    <i class="mdi mdi-home-account me-2 text-primary"></i>
                    <?= $is_update_mode ? 'Update' : 'New' ?> Work From Home Request
                </h5>

                <!-- Rejection Reason Banner (edit mode, rejected) -->
                <?php if ($is_update_mode && $status_val == 2 && !empty($reject_reason_val)): ?>
                <div class="alert alert-danger d-flex align-items-start gap-2 mb-4"
                     style="border-left: 4px solid #dc3545;">
                    <i class="mdi mdi-close-circle-outline fs-5 mt-1 text-danger"></i>
                    <div>
                        <div class="fw-bold text-danger mb-1">
                            <i class="mdi mdi-alert-circle me-1"></i>Rejection Reason
                        </div>
                        <span class="fw-semibold"><?= htmlspecialchars($reject_reason_val) ?></span>
                        <div class="mt-1">
                            <small class="text-muted">
                                Please update your request and re-submit for approval.
                            </small>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <form id="wfh_form" autocomplete="off">

                    <input type="hidden" name="unique_id"
                           value="<?= htmlspecialchars($unique_id_val) ?>">
                    <input type="hidden" name="is_update_mode"
                           value="<?= $is_update_mode ? 'true' : 'false' ?>">
                    <input type="hidden" id="wfh_reporting_officer"
                           value="<?= htmlspecialchars($reporting_officer_id) ?>">

                    <!-- ── Read-only Staff Info ── -->
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Staff Name</label>
                            <input type="text" class="form-control wfh-readonly-field"
                                   value="<?= htmlspecialchars($staff_name_display) ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Employee Code</label>
                            <input type="text" class="form-control wfh-readonly-field"
                                   value="<?= htmlspecialchars($emp_id) ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Department</label>
                            <input type="text" class="form-control wfh-readonly-field"
                                   value="<?= htmlspecialchars($department_display) ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Department Head / Reporting Head
                            </label>
                            <input type="text" class="form-control wfh-readonly-field"
                                   value="<?= htmlspecialchars($department_head_display) ?>" readonly>
                        </div>
                    </div>

                    <hr class="my-4">

                    <!-- ── Date & Day ── -->
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Date <span class="text-danger">*</span>
                            </label>
                            <input type="date" id="wfh_date" name="wfh_date"
                                   class="form-control"
                                   value="<?= htmlspecialchars($wfh_date_val) ?>"
                                   required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Day</label>
                            <input type="text" id="wfh_day"
                                   class="form-control wfh-readonly-field"
                                   value="<?= htmlspecialchars($day_val) ?>"
                                   placeholder="Auto-derived from Date" readonly>
                        </div>
                    </div>

                    <!-- ── Remarks ── -->
                    <div class="mb-4">
                        <label class="form-label fw-semibold">
                            Remarks <span class="text-danger">*</span>
                        </label>
                        <textarea id="wfh_remarks" name="remarks"
                                  class="form-control" rows="4"
                                  placeholder="Enter reason / justification for the WFH request..."
                                  required><?= htmlspecialchars($remarks_val) ?></textarea>
                    </div>

                    <!-- ── Status display (edit mode only) ── -->
                    <?php if ($is_update_mode): ?>
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Current Status</label>
                        <?php
                        $status_badges = [
                            0 => '<span class="badge bg-warning text-dark px-3 py-2">Pending</span>',
                            1 => '<span class="badge bg-success px-3 py-2">Approved</span>',
                            2 => '<span class="badge bg-danger px-3 py-2">Rejected</span>',
                            3 => '<span class="badge bg-secondary px-3 py-2">Cancelled</span>',
                        ];
                        echo '<div class="mt-1">' . ($status_badges[$status_val] ?? '') . '</div>';
                        ?>
                    </div>
                    <?php endif; ?>

                    <!-- ── Buttons ── -->
                    <div class="d-flex gap-2 mt-3">
                        <button type="button" id="wfh_save_btn"
                                class="btn btn-primary waves-effect waves-light"
                                onclick="wfh_cu()">
                            <i class="mdi mdi-content-save me-1"></i>
                            <?= $is_update_mode ? 'Update' : 'Save' ?>
                        </button>
                        <?php echo btn_cancel($btn_cancel); ?>
                    </div>

                </form>

            </div>
        </div>
    </div>

</div>
</div>