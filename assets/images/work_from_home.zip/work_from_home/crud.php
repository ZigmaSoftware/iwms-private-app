<?php
// ─────────────────────────────────────────────
// Bootstrap
// ─────────────────────────────────────────────
$folder_name = explode("/", $_SERVER['PHP_SELF']);
$folder_name = $folder_name[count($folder_name) - 2];

$table = 'work_from_home';

include '../../config/dbconfig.php';
include '../../config/new_db.php';

$action = $_POST['action'] ?? '';

$user_id  = $_SESSION['sess_user_id'] ?? '';
$staff_id = $_SESSION['staff_id']     ?? '';
$date     = date('Y-m-d H:i:s');

// Dynamic approver: logged-in staff is approver if they appear
// as reporting_officer for at least one active staff
$approver_check = $pdo->select(
    ['staff_test', ['COUNT(*) AS cnt']],
    ['reporting_officer' => $staff_id, 'is_delete' => 0, 'is_active' => 1]
);
$is_approver = ($approver_check->status && (int)($approver_check->data[0]['cnt'] ?? 0) > 0);

switch ($action) {

// ─────────────────────────────────────────────
// CREATE / UPDATE
// Validates: weekend, weekly limit, leave conflict, duplicate date
// ─────────────────────────────────────────────
case "createupdate":

    $unique_id_post = (isset($_POST['unique_id']) && $_POST['unique_id'] !== '')
        ? $_POST['unique_id'] : unique_id();

    $emp_id    = $staff_id;                    // always the logged-in staff
    $wfh_date  = $_POST['wfh_date']  ?? '';
    $remarks   = trim($_POST['remarks'] ?? '');
    $is_update = ($_POST['is_update_mode'] ?? 'false') === 'true';

    if (!$wfh_date || !$remarks) {
        echo json_encode(['status' => false, 'error' => 'Date and Remarks are required.']);
        break;
    }

    $eid = addslashes($emp_id);
    $uid = addslashes($unique_id_post);
    $wd  = addslashes($wfh_date);

    // ── Resolve department & reporting officer ────────────────────────
    // FIX: staff_test.department stores department_creation.unique_id
    //      Join on dc.unique_id = st.department (not via department_head)
    $staff_row = $pdo->query("
        SELECT st.reporting_officer, dc.department
        FROM staff_test st
        LEFT JOIN department_creation dc
            ON dc.unique_id  = st.department
            AND dc.is_delete = 0
        WHERE st.employee_id = '$eid'
          AND st.is_delete   = 0
          AND st.is_active   = 1
        LIMIT 1
    ");

    $reporting_officer_id = $staff_row->data[0]['reporting_officer'] ?? '';
    $department_val       = $staff_row->data[0]['department']        ?? '';

    // ── Day derivation ────────────────────────────────────────────────
    $day_val = date('l', strtotime($wfh_date)); // e.g. Monday

    // ── Policy: Block weekends ────────────────────────────────────────
    $dow = date('N', strtotime($wfh_date)); // 1=Mon ... 7=Sun
    if ($dow >= 6) {
        echo json_encode([
            'status'      => false,
            'error_title' => 'Weekend Not Allowed',
            'error'       => 'WFH requests cannot be submitted for Saturday or Sunday.'
        ]);
        break;
    }

    // ── Policy Rule 4: Weekly limit (1 WFH per calendar week) ────────
    $week_mon = date('Y-m-d', strtotime('monday this week', strtotime($wfh_date)));
    $week_sun = date('Y-m-d', strtotime('sunday this week', strtotime($wfh_date)));
    $wm       = addslashes($week_mon);
    $ws       = addslashes($week_sun);

    $week_check_sql = "
            SELECT COUNT(*) AS cnt
            FROM $table
            WHERE employee_id = '$eid'
              AND date >= '$wm'
              AND date <= '$ws'
              AND status NOT IN (2, 3)
              AND is_delete = 0
              " . ($is_update ? "AND unique_id != '$uid'" : "") . "
        ";
    $week_res = $pdo->query($week_check_sql);
    if ($week_res->status && (int)($week_res->data[0]['cnt'] ?? 0) > 0) {
        echo json_encode([
            'status'      => false,
            'error_title' => 'Weekly Limit Reached',
            'error'       => 'You have already applied a WFH request for this calendar week ('
                           . date('d M', strtotime($week_mon)) . ' – '
                           . date('d M Y', strtotime($week_sun))
                           . '). Only one WFH per week is permitted.'
        ]);
        break;
    }

    // ── Policy Rule 2 & 3: Leave conflict check ───────────────────────
    $leave_check_sql = "
        SELECT COUNT(*) AS cnt
        FROM leave_entry
        WHERE employee_id = '$eid'
          AND '$wd' BETWEEN from_date AND to_date
          AND status != 2
          AND is_delete = 0
    ";
    $leave_res = $pdo->query($leave_check_sql);
    if ($leave_res->status && (int)($leave_res->data[0]['cnt'] ?? 0) > 0) {
        echo json_encode([
            'status'      => false,
            'error_title' => 'Leave Conflict',
            'error'       => 'You already have a leave application (pending or approved) on '
                           . date('d M Y', strtotime($wfh_date))
                           . '. WFH cannot be applied on a leave date.'
        ]);
        break;
    }

    // ── Duplicate WFH on same date (non-rejected) ─────────────────────
    $dup_sql = "
        SELECT COUNT(*) AS cnt
        FROM $table
        WHERE employee_id = '$eid'
          AND date = '$wd'
          AND status != 2
          AND is_delete = 0
          " . ($is_update ? "AND unique_id != '$uid'" : "") . "
    ";
    $dup_res = $pdo->query($dup_sql);
    if ($dup_res->status && (int)($dup_res->data[0]['cnt'] ?? 0) > 0) {
        echo json_encode([
            'status'      => false,
            'error_title' => 'Duplicate Request',
            'error'       => 'A WFH request already exists for '
                           . date('d M Y', strtotime($wfh_date)) . '.'
        ]);
        break;
    }

    // ── Save ──────────────────────────────────────────────────────────
    $columns = [
        'employee_id'      => $emp_id,
        'department'       => $department_val,
        'department_head'  => $reporting_officer_id,
        'date'             => $wfh_date,
        'day'              => $day_val,
        'remarks'          => $remarks,
        'status'           => 0,          // always Pending on save / re-submit
        'reject_reason'    => null,       // cleared on re-submit
        'updated_user_id'  => $user_id,
        'updated'          => $date
    ];

    if ($is_update) {
        $action_obj = $pdo->update(
            $table,
            $columns,
            ['unique_id' => $unique_id_post, 'is_delete' => 0]
        );
        $msg = 'WFH request updated and re-submitted for approval.';
    } else {
        $columns['unique_id']       = $unique_id_post;
        $columns['is_active']       = 1;
        $columns['is_delete']       = 0;
        $columns['created_user_id'] = $user_id;
        $columns['created']         = $date;
        $columns['acc_year']        = $_SESSION['acc_year']        ?? '';
        $columns['session_id']      = session_id();
        $columns['sess_user_type']  = $_SESSION['sess_user_type']  ?? '';
        $columns['sess_user_id']    = $_SESSION['sess_user_id']    ?? '';
        $columns['sess_company_id'] = $_SESSION['sess_company_id'] ?? '';
        $columns['sess_branch_id']  = $_SESSION['sess_branch_id']  ?? '';
        $action_obj = $pdo->insert($table, $columns);
        $msg = 'WFH request submitted for approval.';
    }

    echo json_encode([
        'status' => $action_obj->status,
        'msg'    => $msg,
        'error'  => $action_obj->error ?? ''
    ]);
    break;

// ─────────────────────────────────────────────
// VIEW DETAIL
// Used by both creator view modal & approver approval modal
// ─────────────────────────────────────────────
case "wfh_view_detail":

    $unique_id_post = $_POST['unique_id'] ?? '';
    if (!$unique_id_post) {
        echo json_encode(['status' => false, 'error' => 'unique_id is required.']);
        break;
    }

    $rec = $pdo->select(
        [$table, [
            'unique_id', 'employee_id', 'department', 'department_head',
            'date', 'day', 'remarks', 'status', 'reject_reason',
            'approved_by', 'approved_at',
            'rejected_by', 'rejected_at',
            'cancel_reason', 'cancelled_at', 'linked_leave_unique_id',
            'created_user_id', 'created'
        ]],
        ['unique_id' => $unique_id_post, 'is_delete' => 0]
    );

    if (!$rec->status || empty($rec->data)) {
        echo json_encode(['status' => false, 'error' => 'Record not found.']);
        break;
    }

    $row = $rec->data[0];

    // Resolve staff name
    $staff_info     = staff_name_bp($row['employee_id']);
    $staff_name_out = $staff_info[0]['staff_name'] ?? $row['employee_id'];

    // Resolve dept head name
    $dept_head_info = staff_name_bp($row['department_head']);
    $dept_head_name = $dept_head_info[0]['staff_name'] ?? '';

    // Resolve created_by
    $creator_res = $pdo->select(
        ['user', ['user_name']],
        ['unique_id' => $row['created_user_id']]
    );
    $created_by = $creator_res->data[0]['user_name'] ?? '';

    // Resolve approved_by
    $approved_by_name = '';
    if (!empty($row['approved_by'])) {
        $ab_res = $pdo->select(
            ['user', ['user_name']],
            ['unique_id' => $row['approved_by']]
        );
        $approved_by_name = $ab_res->data[0]['user_name'] ?? '';
    }

    // Resolve rejected_by
    $rejected_by_name = '';
    if (!empty($row['rejected_by'])) {
        $rb_res = $pdo->select(
            ['user', ['user_name']],
            ['unique_id' => $row['rejected_by']]
        );
        $rejected_by_name = $rb_res->data[0]['user_name'] ?? '';
    }

    echo json_encode([
        'status' => true,
        'data'   => [
            'unique_id'              => $row['unique_id'],
            'employee_id'            => $row['employee_id'],
            'staff_name'             => $staff_name_out,
            'department'             => $row['department']    ?? '',
            'dept_head_name'         => $dept_head_name,
            'date'                   => $row['date'],
            'day'                    => $row['day']            ?? '',
            'remarks'                => htmlspecialchars($row['remarks'] ?? ''),
            'status'                 => (int)$row['status'],
            'reject_reason'          => htmlspecialchars($row['reject_reason'] ?? ''),
            'approved_by'            => $approved_by_name,
            'approved_at'            => $row['approved_at']   ?? '',
            'rejected_by'            => $rejected_by_name,
            'rejected_at'            => $row['rejected_at']   ?? '',
            'cancel_reason'          => htmlspecialchars($row['cancel_reason'] ?? ''),
            'cancelled_at'           => $row['cancelled_at']  ?? '',
            'linked_leave_unique_id' => $row['linked_leave_unique_id'] ?? '',
            'created_by'             => $created_by,
            'created_at'             => $row['created']       ?? '',
        ]
    ]);
    break;
    
    
    case "check_leave_conflict":

    $emp_id   = $staff_id;
    $check_dt = $_POST['wfh_date'] ?? '';

    if (!$check_dt) {
        echo json_encode(['status' => true, 'has_conflict' => false]);
        break;
    }

    $eid = addslashes($emp_id);
    $cd  = addslashes($check_dt);

    $leave_res = $pdo->query("
        SELECT status FROM leave_entry
        WHERE employee_id = '$eid'
          AND '$cd' BETWEEN from_date AND to_date
          AND status != 2
          AND is_delete = 0
        LIMIT 1
    ");

    $has_conflict = false;
    $is_approved  = false;

    if ($leave_res->status && !empty($leave_res->data)) {
        $has_conflict = true;
        $is_approved  = ((int)$leave_res->data[0]['status'] === 1);
    }

    echo json_encode([
        'status'       => true,
        'has_conflict' => $has_conflict,
        'is_approved'  => $is_approved
    ]);
    break;
    

// ─────────────────────────────────────────────
// APPROVE (Approver only)
// ─────────────────────────────────────────────
case "wfh_approve":

    if (!$is_approver) {
        echo json_encode(['status' => false, 'error' => 'Unauthorized.']);
        break;
    }

    $unique_id_post = $_POST['unique_id'] ?? '';
    if (!$unique_id_post) {
        echo json_encode(['status' => false, 'error' => 'unique_id is required.']);
        break;
    }

    // Confirm this record belongs to one of the approver's reportees
    $uid = addslashes($unique_id_post);
    $sid = addslashes($staff_id);

    $auth_check = $pdo->query("
        SELECT COUNT(*) AS cnt
        FROM $table wfh
        WHERE wfh.unique_id = '$uid'
          AND (
              wfh.department_head = '$sid'
              OR wfh.department_head = (
                  SELECT unique_id FROM staff_test
                  WHERE employee_id = '$sid'
                    AND is_delete = 0 AND is_active = 1
                  LIMIT 1
              )
          )
          AND wfh.is_delete = 0
    ");
    if (!$auth_check->status || (int)($auth_check->data[0]['cnt'] ?? 0) === 0) {
        echo json_encode(['status' => false, 'error' => 'Record not found or not your reportee.']);
        break;
    }

    $action_obj = $pdo->update(
        $table,
        [
            'status'          => 1,
            'approved_by'     => $user_id,
            'approved_at'     => $date,
            'updated_user_id' => $user_id,
            'updated'         => $date
        ],
        ['unique_id' => $unique_id_post, 'is_delete' => 0]
    );

    echo json_encode([
        'status' => $action_obj->status,
        'msg'    => $action_obj->status ? 'approved' : 'error',
        'error'  => $action_obj->error ?? ''
    ]);
    break;

// ─────────────────────────────────────────────
// REJECT (Approver only)
// ─────────────────────────────────────────────
case "wfh_reject":

    if (!$is_approver) {
        echo json_encode(['status' => false, 'error' => 'Unauthorized.']);
        break;
    }

    $unique_id_post = $_POST['unique_id']     ?? '';
    $reject_reason  = trim($_POST['reject_reason'] ?? '');

    if (!$unique_id_post) {
        echo json_encode(['status' => false, 'error' => 'unique_id is required.']);
        break;
    }
    if (!$reject_reason) {
        echo json_encode(['status' => false, 'error' => 'Rejection reason is required.']);
        break;
    }

    $uid = addslashes($unique_id_post);
    $sid = addslashes($staff_id);

    $auth_check = $pdo->query("
        SELECT COUNT(*) AS cnt
        FROM $table wfh
        WHERE wfh.unique_id = '$uid'
          AND (
              wfh.department_head = '$sid'
              OR wfh.department_head = (
                  SELECT unique_id FROM staff_test
                  WHERE employee_id = '$sid'
                    AND is_delete = 0 AND is_active = 1
                  LIMIT 1
              )
          )
          AND wfh.is_delete = 0
    ");
    if (!$auth_check->status || (int)($auth_check->data[0]['cnt'] ?? 0) === 0) {
        echo json_encode(['status' => false, 'error' => 'Record not found or not your reportee.']);
        break;
    }

    $action_obj = $pdo->update(
        $table,
        [
            'status'          => 2,
            'reject_reason'   => $reject_reason,
            'rejected_by'     => $user_id,
            'rejected_at'     => $date,
            'updated_user_id' => $user_id,
            'updated'         => $date
        ],
        ['unique_id' => $unique_id_post, 'is_delete' => 0]
    );

    echo json_encode([
        'status' => $action_obj->status,
        'msg'    => $action_obj->status ? 'rejected' : 'error',
        'error'  => $action_obj->error ?? ''
    ]);
    break;

// ─────────────────────────────────────────────
// DELETE (soft-delete, creator only, Pending only)
// ─────────────────────────────────────────────
case "delete":

    $unique_id_post = $_POST['unique_id'] ?? '';
    if (!$unique_id_post) {
        echo json_encode(['status' => false, 'error' => 'unique_id is required.']);
        break;
    }

    $uid = addslashes($unique_id_post);

    $del_check = $pdo->query("
        SELECT status, created_user_id
        FROM $table
        WHERE unique_id = '$uid' AND is_delete = 0
        LIMIT 1
    ");

    if (!$del_check->status || empty($del_check->data)) {
        echo json_encode(['status' => false, 'error' => 'Record not found.']);
        break;
    }

    $del_row = $del_check->data[0];

    if ($del_row['created_user_id'] !== $user_id) {
        echo json_encode(['status' => false, 'error' => 'Unauthorized. Only the creator can delete.']);
        break;
    }
    if ((int)$del_row['status'] !== 0) {
        echo json_encode(['status' => false, 'error' => 'Only Pending requests can be deleted.']);
        break;
    }

    $action_obj = $pdo->update(
        $table,
        ['is_delete' => 1, 'updated_user_id' => $user_id, 'updated' => $date],
        ['unique_id' => $unique_id_post]
    );

    echo json_encode([
        'status' => $action_obj->status,
        'msg'    => $action_obj->status ? 'deleted' : 'error',
        'error'  => $action_obj->error ?? ''
    ]);
    break;

// ─────────────────────────────────────────────
// DATATABLE — Server-side, view_type aware
//
// view_type = "own"  → employee sees their own records (employee_id filter)
// view_type = "team" → approver sees reportees' records (department_head filter)
//
// Column count per view_type:
//   own  → 8 cols: #, Staff Name, Dept, Date, Day, Status, View, Actions
//   team → 7 cols: #, Staff Name, Dept, Date, Day, Approval Action, Status
// ─────────────────────────────────────────────
case "datatable":

    $draw        = intval($_POST['draw']   ?? 1);
    $length      = intval($_POST['length'] ?? 10);
    $start       = intval($_POST['start']  ?? 0);

    $view_type    = $_POST['view_type']      ?? 'own';   // "own" or "team"
    $logged_staff = $_POST['logged_staff_id'] ?? '';
    $logged_user  = $_POST['logged_user_id']  ?? '';
    $filter_from  = $_POST['filter_from']     ?? '';
    $filter_to    = $_POST['filter_to']       ?? '';
    $filter_status = $_POST['filter_status']  ?? '';

    // NOTE: status 3 (Cancelled) added — used when an approved Leave
    // is later applied for the same date and auto-cancels this WFH.
    $status_labels = [
        0 => ['label' => 'Pending',   'class' => 'warning text-dark'],
        1 => ['label' => 'Approved',  'class' => 'success'],
        2 => ['label' => 'Rejected',  'class' => 'danger'],
        3 => ['label' => 'Cancelled', 'class' => 'secondary'],
    ];

    $where_parts = ["wfh.is_delete = 0"];

    if ($view_type === 'team') {
        // Server-side guard: only approvers can pull team view
        if (!$is_approver) {
            echo json_encode([
                'draw' => $draw, 'recordsTotal' => 0,
                'recordsFiltered' => 0, 'data' => []
            ]);
            break;
        }
        // Filter: records where department_head = logged-in staff
        // Covers both employee_id and unique_id storage formats
        $sid = addslashes($logged_staff);
        $where_parts[] = "
            (
                wfh.department_head = '$sid'
                OR wfh.department_head = (
                    SELECT unique_id FROM staff_test
                    WHERE employee_id = '$sid'
                      AND is_delete = 0 AND is_active = 1
                    LIMIT 1
                )
            )
        ";
    } else {
        // "own" view: employee sees only their records
        $eid = addslashes($logged_staff);
        $where_parts[] = "wfh.employee_id = '$eid'";
    }

    if (!empty($filter_from)) {
        $ff = addslashes($filter_from);
        $where_parts[] = "wfh.date >= '$ff'";
    }
    if (!empty($filter_to)) {
        $ft = addslashes($filter_to);
        $where_parts[] = "wfh.date <= '$ft'";
    }
    if ($filter_status !== '') {
        $fs = (int)$filter_status;
        $where_parts[] = "wfh.status = $fs";
    }

    $where_sql = implode(' AND ', $where_parts);

    // Total count
    $count_res = $pdo->query("
        SELECT COUNT(*) AS total
        FROM $table wfh
        WHERE $where_sql
    ");
    $total = (int)($count_res->data[0]['total'] ?? 0);

    // Paginated data
    $limit_clause = ($length != -1) ? "LIMIT $length OFFSET $start" : "";

    $sql = "
        SELECT
            @rn := @rn + 1 AS s_no,
            t.*
        FROM (
            SELECT
                wfh.unique_id,
                wfh.employee_id,
                wfh.department,
                wfh.date,
                wfh.day,
                wfh.status,
                wfh.created_user_id
            FROM $table wfh
            WHERE $where_sql
            ORDER BY wfh.date DESC
        ) t
        JOIN (SELECT @rn := $start) r
        $limit_clause
    ";

    $result = $pdo->query($sql);

    $data = [];
    if ($result && !empty($result->data)) {
        foreach ($result->data as $row) {
            $uid             = $row['unique_id'];
            $approval_status = (int)$row['status'];
            $row_creator_id  = $row['created_user_id'];

            // Staff name
            $staff_info = staff_name_bp($row['employee_id']);
            $staff_name = $staff_info[0]['staff_name'] ?? $row['employee_id'];

            // Status badge
            $si           = $status_labels[$approval_status] ?? ['label' => 'Unknown', 'class' => 'secondary'];
            $status_badge = '<span class="badge bg-' . $si['class'] . '">' . $si['label'] . '</span>';
            
            // Override for auto-cancelled (leave approved) — show extra context in Status column
if ($approval_status === 3) {
    $status_badge = '<span class="badge bg-secondary">
        <i class="mdi mdi-cancel"></i> Cancelled (Leave Approved)</span>';
}

            if ($view_type === 'team') {
                // ── TEAM VIEW: 7 columns ──────────────────────────────
                // #, Staff Name, Dept, Date, Day, Approval Action, Status
                $btn_approval = '<button type="button"
                    class="btn btn-sm btn-soft-primary"
                    onclick="wfh_open_approval_view(\'' . $uid . '\')">
                    <i class="mdi mdi-clipboard-check-outline"></i> Review
                </button>';

                $data[] = [
                    $row['s_no'],
                    htmlspecialchars($staff_name),
                    htmlspecialchars($row['department'] ?? ''),
                    $row['date'],
                    $row['day'] ?? '',
                    $btn_approval,
                    $status_badge,
                ];

            } else {
                // ── OWN VIEW: 8 columns ───────────────────────────────
                // #, Staff Name, Dept, Date, Day, Status, View, Actions

                // View button — everyone can view their own
                $btn_view = '<button type="button"
                    class="btn btn-sm btn-soft-info"
                    onclick="wfh_open_view(\'' . $uid . '\')">
                    <i class="mdi mdi-eye"></i>
                </button>';

                // Actions — only the creator, based on status
                $action_col = '';
                if ($row_creator_id === $logged_user) {
                    if ($approval_status === 0) {
                        // Pending: edit + delete
                        $edit_url   = "index.php?file=work_from_home/form&unique_id={$uid}";
                        $action_col = '<a href="' . $edit_url . '"
                            class="btn btn-sm btn-soft-primary me-1">
                            <i class="mdi mdi-pencil"></i></a>'
                            . '<button type="button"
                            class="btn btn-sm btn-soft-danger"
                            onclick="wfh_delete(\'' . $uid . '\')">
                            <i class="mdi mdi-trash-can-outline"></i></button>';

                    } elseif ($approval_status === 2) {
                        // Rejected: edit & re-submit
                        $edit_url   = "index.php?file=work_from_home/form&unique_id={$uid}";
                        $action_col = '<a href="' . $edit_url . '"
                            class="btn btn-sm btn-soft-warning">
                            <i class="mdi mdi-pencil"></i> Edit & Re-submit</a>';

                    } elseif ($approval_status === 1) {
                        // Approved: locked
                        $action_col = '<span class="badge bg-secondary">
                            <i class="mdi mdi-lock"></i> Locked</span>';

                    } elseif ($approval_status === 3) {
                        // Cancelled (auto, due to approved Leave on same date): locked
                        $action_col = '<span class="badge bg-secondary">
                            <i class="mdi mdi-cancel"></i> Cancelled</span>';
                    }
                } else {
                    $action_col = '<span class="badge bg-light text-muted">—</span>';
                }

                $data[] = [
                    $row['s_no'],
                    htmlspecialchars($staff_name),
                    htmlspecialchars($row['department'] ?? ''),
                    $row['date'],
                    $row['day'] ?? '',
                    $status_badge,
                    $btn_view,
                    $action_col,
                ];
            }
        }
    }

    echo json_encode([
        'draw'            => $draw,
        'recordsTotal'    => $total,
        'recordsFiltered' => $total,
        'data'            => $data
    ]);
    break;

default:
    echo json_encode(['status' => false, 'msg' => 'Invalid action']);
    break;
}
?>