var ajax_url = sessionStorage.getItem("folder_crud_link");
var list_url  = sessionStorage.getItem("list_link");

var wfh_current_uid = "";

// ─────────────────────────────────────────────
// Safe redirect — suppress "Leave site?" popup
// ─────────────────────────────────────────────
function wfh_safe_redirect(target) {
    window.onbeforeunload = null;
    $(window).off("beforeunload");
    if (target) window.location.href = target;
}

// ─────────────────────────────────────────────
// Document Ready
// ─────────────────────────────────────────────
$(document).ready(function () {

    // ── Form page: Date → Day auto-derive ──
    if ($("#wfh_date").length) {

        $("#wfh_date").on("change", function () {
    var d = $(this).val();
    if (d) {
        var days = ["Sunday","Monday","Tuesday","Wednesday",
                    "Thursday","Friday","Saturday"];
        var dt = new Date(d + "T00:00:00");
        $("#wfh_day").val(days[dt.getDay()]);

        // ── NEW: check leave conflict on date pick ──
        $.ajax({
            type: "POST",
            url:  ajax_url,
            data: { action: "check_leave_conflict", wfh_date: d },
            success: function (res) {
                var obj = (typeof res === "string") ? JSON.parse(res) : res;
                if (obj.status && obj.has_conflict) {
                    var msg = obj.is_approved
                        ? "You have an approved Leave for this date. You cannot apply Work From Home for this date."
                        : "You already have a Leave application (pending) for this date. WFH cannot be applied on a leave date.";

                    Swal.fire({
                        icon: "warning",
                        title: "Leave Conflict",
                        text: msg
                    });

                    $("#wfh_date").val("");
                    $("#wfh_day").val("");
                    $("#wfh_save_btn").prop("disabled", true);
                } else {
                    $("#wfh_save_btn").prop("disabled", false);
                }
            }
        });
    } else {
        $("#wfh_day").val("");
    }
});

        // Trigger on edit mode where date is pre-filled
        if ($("#wfh_date").val()) {
            $("#wfh_date").trigger("change");
        }
    }

    // ── List page: Init DataTables ──
    // "My Requests" table — always present on list page
    if ($("#wfh_datatable").length) {
        wfh_init_datatable("own");
    }

    // "Team Requests" table — present only for approvers
    if ($("#wfh_datatable_team").length) {
        wfh_init_datatable("team");

        // Re-init team table when its tab is first shown
        // (DataTables in hidden tabs can have column-width issues)
        $("#tab-team-btn").on("shown.bs.tab", function () {
            if ($.fn.DataTable.isDataTable("#wfh_datatable_team")) {
                $("#wfh_datatable_team").DataTable().columns.adjust().draw(false);
            }
        });
    }
});

// ─────────────────────────────────────────────
// DataTable Init
// view_type: "own"  → My Requests  (employee_id filter)
//            "team" → Team Requests (department_head filter)
// ─────────────────────────────────────────────
function wfh_init_datatable(view_type) {

    var table_id = (view_type === "team") ? "#wfh_datatable_team" : "#wfh_datatable";
    var table    = $(table_id);

    if (!table.length) return;

    if ($.fn.DataTable.isDataTable(table)) {
        table.DataTable().clear().destroy();
    }

    table.DataTable({
        processing: true,
        serverSide: true,
        ordering:   true,
        searching:  false,
        ajax: {
            url:  ajax_url,
            type: "POST",
            data: {
                action:          "datatable",
                view_type:       view_type,
                logged_staff_id: $("#js_logged_staff_id").val(),
                logged_user_id:  $("#js_logged_user_id").val(),
                filter_from:     $("#wfh_filter_from").val()   || "",
                filter_to:       $("#wfh_filter_to").val()     || "",
                filter_status:   $("#wfh_filter_status").val() || ""
            },
            dataSrc: function (json) {
                return json.data || [];
            },
            error: function (xhr, status, error) {
                console.error("WFH DataTable (" + view_type + ") Error:", error);
            }
        },
        columnDefs: [{ targets: "_all", defaultContent: "" }],
        language:   { emptyTable: "No WFH requests found." }
    });
}

// ─────────────────────────────────────────────
// Filter — refreshes whichever tables exist
// ─────────────────────────────────────────────
function wfhFilter() {
    if ($("#wfh_datatable").length)      wfh_init_datatable("own");
    if ($("#wfh_datatable_team").length) wfh_init_datatable("team");
}

// ─────────────────────────────────────────────
// Create / Update Submit
// ─────────────────────────────────────────────
function wfh_cu() {

    var date    = $("#wfh_date").val();
    var remarks = $.trim($("#wfh_remarks").val());

    if (!date) {
        Swal.fire({ icon: "warning", title: "Required", text: "Please select a Date." });
        return;
    }
    if (!remarks) {
        Swal.fire({ icon: "warning", title: "Required", text: "Please enter Remarks." });
        return;
    }

    var formData = new FormData(document.getElementById("wfh_form"));
    formData.append("action", "createupdate");

    $.ajax({
        url:         ajax_url,
        type:        "POST",
        data:        formData,
        processData: false,
        contentType: false,
        beforeSend: function () {
            $("#wfh_save_btn").prop("disabled", true).text("Saving...");
        },
        success: function (res) {
            var obj;
            try { obj = (typeof res === "string") ? JSON.parse(res) : res; }
            catch (e) {
                Swal.fire({ icon: "error", title: "Invalid Response" });
                $("#wfh_save_btn").prop("disabled", false).text("Save");
                return;
            }

            if (obj.status) {
                Swal.fire({
                    icon:  "success",
                    title: "Success!",
                    text:  obj.msg || "WFH request submitted successfully.",
                    timer: 1500,
                    showConfirmButton: false
                }).then(function () { wfh_safe_redirect(list_url); });
            } else {
                Swal.fire({
                    icon:  "error",
                    title: obj.error_title || "Error",
                    text:  obj.error       || "Save failed."
                });
                var is_update = $("#wfh_form input[name='is_update_mode']").val() === "true";
                $("#wfh_save_btn").prop("disabled", false)
                                  .text(is_update ? "Update" : "Save");
            }
        },
        error: function () {
            Swal.fire({ icon: "error", title: "Network Error" });
            $("#wfh_save_btn").prop("disabled", false).text("Save");
        }
    });
}

// ─────────────────────────────────────────────
// Delete
// ─────────────────────────────────────────────
function wfh_delete(unique_id) {
    Swal.fire({
        title: "Delete this WFH request?",
        text:  "This action cannot be undone.",
        icon:  "warning",
        showCancelButton:   true,
        confirmButtonText:  "Yes, delete",
        confirmButtonColor: "#d33"
    }).then(function (result) {
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url:  ajax_url,
                data: { action: "delete", unique_id: unique_id },
                success: function (res) {
                    var obj = (typeof res === "string") ? JSON.parse(res) : res;
                    if (obj.status) {
                        Swal.fire({
                            icon: "success", title: "Deleted!",
                            timer: 1200, showConfirmButton: false
                        });
                        wfh_init_datatable("own");
                    } else {
                        Swal.fire({
                            icon: "error", title: "Error",
                            text: obj.error || "Could not delete."
                        });
                    }
                },
                error: function () {
                    Swal.fire({ icon: "error", title: "Network Error" });
                }
            });
        }
    });
}

// ─────────────────────────────────────────────
// My Requests — View Modal (all roles)
// ─────────────────────────────────────────────
function wfh_open_view(unique_id) {
    wfh_current_uid = unique_id;
    $("#wfhViewModalBody").html(wfh_spinner());
    $("#wfhViewModal").modal("show");

    $.ajax({
        type: "POST", url: ajax_url,
        data: { action: "wfh_view_detail", unique_id: unique_id },
        success: function (res) {
            var obj = (typeof res === "string") ? JSON.parse(res) : res;
            if (!obj.status) {
                Swal.fire({ icon: "error", title: "Error", text: obj.error || "Could not load." });
                return;
            }
            $("#wfhViewModalBody").html(wfh_build_detail_html(obj.data, false));
        },
        error: function () { Swal.fire({ icon: "error", title: "Network Error" }); }
    });
}

// ─────────────────────────────────────────────
// Team Requests — Approval Modal (approvers)
// ─────────────────────────────────────────────
function wfh_open_approval_view(unique_id) {
    wfh_current_uid = unique_id;
    $("#wfhApprovalModalBody").html(wfh_spinner());
    $("#wfhApprovalModal").modal("show");

    $.ajax({
        type: "POST", url: ajax_url,
        data: { action: "wfh_view_detail", unique_id: unique_id },
        success: function (res) {
            var obj = (typeof res === "string") ? JSON.parse(res) : res;
            if (!obj.status) {
                Swal.fire({ icon: "error", title: "Error", text: obj.error || "Could not load." });
                return;
            }
            var d = obj.data;
            $("#wfhApprovalModalTitle").html(
            '<span class="text-white">' +
            '<i class="mdi mdi-clipboard-check-outline me-2"></i>WFH Approval — ' +
            (d.staff_name || "") +
            '</span>'
        );
            $("#wfhApprovalModalBody").html(wfh_build_detail_html(d, true));
        },
        error: function () { Swal.fire({ icon: "error", title: "Network Error" }); }
    });
}

// ─────────────────────────────────────────────
// Build modal detail HTML (shared)
// is_approver_view = true → show approve/reject actions when status=0
// status: 0=Pending, 1=Approved, 2=Rejected, 3=Cancelled (auto, leave approved)
// ─────────────────────────────────────────────
function wfh_build_detail_html(d, is_approver_view) {

    var statusMap = {
        "0": "<span class='badge bg-warning text-dark'>Pending</span>",
        "1": "<span class='badge bg-success'>Approved</span>",
        "2": "<span class='badge bg-danger'>Rejected</span>",
        "3": "<span class='badge bg-secondary'>Cancelled</span>"
    };

    var status = parseInt(d.status, 10);
    var html   = "";

    // Section A — Request Data
    html += '<h6 class="fw-bold text-primary mb-2">Request Details</h6>';
    html += '<table class="table table-bordered table-sm mb-3"><tbody>';
    html += '<tr><th style="width:38%">Staff Name</th><td>'   + (d.staff_name      || "-") + "</td></tr>";
    html += '<tr><th>Employee Code</th><td>'                   + (d.employee_id     || "-") + "</td></tr>";
    html += '<tr><th>Department</th><td>'                      + (d.department      || "-") + "</td></tr>";
    html += '<tr><th>Department Head</th><td>'                 + (d.dept_head_name  || "-") + "</td></tr>";
    html += '<tr><th>Date</th><td>'                            + (d.date            || "-") + "</td></tr>";
    html += '<tr><th>Day</th><td>'                             + (d.day             || "-") + "</td></tr>";
    html += '<tr><th>Remarks</th><td>'                         + (d.remarks         || "-") + "</td></tr>";
    html += '<tr><th>Status</th><td>'                          + (statusMap[String(d.status)] || "-") + "</td></tr>";
    html += "</tbody></table>";

    // Section B — Submission Info
    html += '<h6 class="fw-bold text-primary mb-2">Submission Info</h6>';
    html += '<table class="table table-bordered table-sm mb-3"><tbody>';
    html += '<tr><th style="width:38%">Created By</th><td>' + (d.created_by || "-") + "</td></tr>";
    html += '<tr><th>Created At</th><td>'                   + (d.created_at || "-") + "</td></tr>";
    html += "</tbody></table>";

    // Section C — Post-action info
    if (status === 1) {
        html += '<h6 class="fw-bold text-primary mb-2">Approval Info</h6>';
        html += '<table class="table table-bordered table-sm mb-3"><tbody>';
        html += '<tr><th style="width:38%">Approved By</th><td>' + (d.approved_by || "-") + "</td></tr>";
        html += '<tr><th>Approved At</th><td>'                   + (d.approved_at || "-") + "</td></tr>";
        html += "</tbody></table>";
    } else if (status === 2) {
        html += '<h6 class="fw-bold text-primary mb-2">Rejection Info</h6>';
        html += '<table class="table table-bordered table-sm mb-3"><tbody>';
        html += '<tr><th style="width:38%">Rejected By</th><td>'           + (d.rejected_by   || "-") + "</td></tr>";
        html += '<tr><th>Rejected At</th><td>'                             + (d.rejected_at   || "-") + "</td></tr>";
        html += '<tr><th>Rejection Reason</th><td class="text-danger fw-semibold">'
                    + (d.reject_reason || "-") + "</td></tr>";
        html += "</tbody></table>";
    } else if (status === 3) {
        // Auto-cancelled because an approved Leave now covers this date
        html += '<h6 class="fw-bold text-primary mb-2">Cancellation Info</h6>';
        html += '<table class="table table-bordered table-sm mb-3"><tbody>';
        html += '<tr><th style="width:38%">Cancelled At</th><td>' + (d.cancelled_at || "-") + "</td></tr>";
        html += '<tr><th>Reason</th><td class="text-secondary fw-semibold">'
                    + (d.cancel_reason || "-") + "</td></tr>";
        // if (d.linked_leave_unique_id) {
        //     html += '<tr><th>Linked Leave Ref</th><td>' + d.linked_leave_unique_id + "</td></tr>";
        // }
        html += "</tbody></table>";
    }

    // Section D — Approver Actions (Team modal, Pending only)
    if (is_approver_view && status === 0) {
        html += '<h6 class="fw-bold text-primary mb-2">Approval Action</h6>';
        html += '<div class="d-flex gap-2 align-items-start flex-wrap">';

        html += '<button type="button" class="btn btn-success" onclick="wfh_approve()">'
              + '<i class="mdi mdi-check-circle me-1"></i> Approve</button>';

        html += '<div>';
        html += '<button type="button" class="btn btn-danger" onclick="wfh_toggle_reject()">'
              + '<i class="mdi mdi-close-circle me-1"></i> Reject</button>';
        html += '<div id="wfh_reject_wrapper" style="display:none;" class="mt-2">';
        html += '<textarea id="wfh_reject_reason" class="form-control mb-2" rows="3"'
              + ' placeholder="Enter rejection reason (required)..."></textarea>';
        html += '<button type="button" class="btn btn-danger btn-sm"'
              + ' onclick="wfh_confirm_reject()">Confirm Rejection</button>';
        html += '<button type="button" class="btn btn-secondary btn-sm ms-1"'
              + ' onclick="wfh_toggle_reject(true)">Cancel</button>';
        html += "</div></div>";

        html += "</div>";
    }

    return html;
}

// ─────────────────────────────────────────────
// Approve
// ─────────────────────────────────────────────
function wfh_approve() {
    Swal.fire({
        title: "Approve this WFH request?",
        icon:  "question",
        showCancelButton:   true,
        confirmButtonText:  "Yes, Approve",
        confirmButtonColor: "#28a745"
    }).then(function (result) {
        if (result.isConfirmed) {
            $.ajax({
                type: "POST", url: ajax_url,
                data: { action: "wfh_approve", unique_id: wfh_current_uid },
                success: function (res) {
                    var obj = (typeof res === "string") ? JSON.parse(res) : res;
                    if (obj.status) {
                        Swal.fire({
                            icon: "success", title: "Approved!",
                            timer: 1500, showConfirmButton: false
                        }).then(function () {
                            $("#wfhApprovalModal").modal("hide");
                            wfh_init_datatable("team");
                        });
                    } else {
                        Swal.fire({
                            icon: "error", title: "Error",
                            text: obj.error || "Approval failed."
                        });
                    }
                },
                error: function () { Swal.fire({ icon: "error", title: "Network Error" }); }
            });
        }
    });
}

// ─────────────────────────────────────────────
// Toggle Reject Reason input
// ─────────────────────────────────────────────
function wfh_toggle_reject(hide) {
    if (hide) {
        $("#wfh_reject_wrapper").hide();
        $("#wfh_reject_reason").val("");
    } else {
        $("#wfh_reject_wrapper").toggle();
    }
}

// ─────────────────────────────────────────────
// Confirm Rejection
// ─────────────────────────────────────────────
function wfh_confirm_reject() {
    var reason = $.trim($("#wfh_reject_reason").val());
    if (!reason) {
        Swal.fire({ icon: "warning", title: "Required",
                    text: "Please enter a rejection reason." });
        return;
    }

    $.ajax({
        type: "POST", url: ajax_url,
        data: {
            action:        "wfh_reject",
            unique_id:     wfh_current_uid,
            reject_reason: reason
        },
        success: function (res) {
            var obj = (typeof res === "string") ? JSON.parse(res) : res;
            if (obj.status) {
                Swal.fire({
                    icon: "success", title: "Rejected!",
                    timer: 1500, showConfirmButton: false
                }).then(function () {
                    $("#wfhApprovalModal").modal("hide");
                    wfh_init_datatable("team");
                });
            } else {
                Swal.fire({
                    icon: "error", title: "Error",
                    text: obj.error || "Rejection failed."
                });
            }
        },
        error: function () { Swal.fire({ icon: "error", title: "Network Error" }); }
    });
}

// ─────────────────────────────────────────────
// Spinner helper
// ─────────────────────────────────────────────
function wfh_spinner() {
    return '<div class="text-center py-5">'
         + '<div class="spinner-border text-primary" role="status"></div>'
         + "</div>";
}