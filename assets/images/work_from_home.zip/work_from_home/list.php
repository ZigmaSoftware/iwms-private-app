<?php
// ─────────────────────────────────────────────
// Session
// ─────────────────────────────────────────────
$logged_staff_id = $_SESSION['staff_id']     ?? '';
$logged_user_id  = $_SESSION['sess_user_id'] ?? '';

// ─────────────────────────────────────────────
// Dynamic Approver Check
// ─────────────────────────────────────────────
$approver_check = $pdo->select(
    ['staff_test', ['COUNT(*) AS cnt']],
    ['reporting_officer' => $logged_staff_id, 'is_delete' => 0, 'is_active' => 1]
);
$is_approver = ($approver_check->status && (int)($approver_check->data[0]['cnt'] ?? 0) > 0);

// ─────────────────────────────────────────────
// Filter Options
// ─────────────────────────────────────────────
$status_options_list = [
    ['unique_id' => '0', 'value' => 'Pending'],
    ['unique_id' => '1', 'value' => 'Approved'],
    ['unique_id' => '2', 'value' => 'Rejected'],
];
$status_opt = select_option($status_options_list, 'All Status');

$start_date = date('Y-m-01');
$end_date   = date('Y-m-t');
?>

<style>
.filter-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
}
.filter-card .form-label { font-size: 12px; font-weight: 500; letter-spacing: 0.3px; }
.table thead th { font-size: 13px; letter-spacing: 0.3px; }
.table tbody td { font-size: 14px; vertical-align: middle; }
.badge { padding: 6px 10px; font-weight: 500; }
.nav-tabs .nav-link { font-weight: 500; color: #64748b; }
.nav-tabs .nav-link.active { color: #0d6efd; border-bottom: 2px solid #0d6efd; }
</style>

<div class="row">
    <div class="col-12">
        <div class="card shadow-sm">
            <div class="card-body">

                <!-- ── Header ── -->
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0 fw-semibold">
                        <i class="mdi mdi-home-account me-2 text-primary"></i>
                        Work From Home Requests
                    </h5>
                    <?= btn_add($btn_add) ?>
                </div>

                <!-- ── Filters (shared across both tabs) ── -->
                <div class="card filter-card shadow-sm mb-4">
                    <div class="card-body">
                        <div class="row g-3 align-items-end">
                            <div class="col-md-3">
                                <label class="form-label text-muted">From Date</label>
                                <input type="date" id="wfh_filter_from"
                                       class="form-control" value="<?= $start_date ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label text-muted">To Date</label>
                                <input type="date" id="wfh_filter_to"
                                       class="form-control" value="<?= $end_date ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label text-muted">Status</label>
                                <select id="wfh_filter_status" class="form-control select2">
                                    <?= $status_opt ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <button type="button"
                                        class="btn btn-primary btn-rounded w-100"
                                        onclick="wfhFilter()">
                                    <i class="mdi mdi-filter me-1"></i> Go
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ════════════════════════════════════════
                     APPROVAL VIEW MODAL (Approver — Team tab)
                ════════════════════════════════════════ -->
                <div class="modal fade" id="wfhApprovalModal" tabindex="-1"
                     role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header bg-primary text-white">
                                <h5 class="modal-title fw-bold" id="wfhApprovalModalTitle">
                                    <i class="mdi mdi-clipboard-check-outline me-2"></i>
                                    WFH Approval View
                                </h5>
                                <button type="button" class="btn-close btn-close-white"
                                        data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body" id="wfhApprovalModalBody">
                                <div class="text-center py-5">
                                    <div class="spinner-border text-primary" role="status"></div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ════════════════════════════════════════
                     VIEW MODAL (My Requests tab — all roles)
                ════════════════════════════════════════ -->
                <div class="modal fade" id="wfhViewModal" tabindex="-1"
                     role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-md" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title fw-bold">
                                    <i class="mdi mdi-eye-outline me-2"></i>
                                    WFH Request Details
                                </h5>
                                <button type="button" class="btn-close"
                                        data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body" id="wfhViewModalBody">
                                <div class="text-center py-5">
                                    <div class="spinner-border text-primary" role="status"></div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ════════════════════════════════════════
                     TAB NAVIGATION (approvers see both tabs,
                     non-approvers only see My Requests)
                ════════════════════════════════════════ -->
                <?php if ($is_approver): ?>
                <ul class="nav nav-tabs mb-3" id="wfhTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="tab-my-btn"
                                data-bs-toggle="tab" data-bs-target="#tab_my_requests"
                                type="button" role="tab">
                            <i class="mdi mdi-account me-1"></i> My Requests
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="tab-team-btn"
                                data-bs-toggle="tab" data-bs-target="#tab_team_requests"
                                type="button" role="tab">
                            <i class="mdi mdi-account-group me-1"></i> Team Requests
                        </button>
                    </li>
                </ul>
                <?php endif; ?>

                <!-- ════════════════════════════════════════
                     TAB CONTENT
                ════════════════════════════════════════ -->
                <div class="tab-content">

                    <!-- ── MY REQUESTS TAB (all roles) ── -->
                    <div class="tab-pane fade show active"
                         id="tab_my_requests" role="tabpanel">
                        <div class="table-responsive">
                            <table id="wfh_datatable"
                                   class="table table-hover table-bordered align-middle w-100">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Staff Name</th>
                                        <th>Department</th>
                                        <th>Date</th>
                                        <th>Day</th>
                                        <th class="text-center">Status</th>
                                        <th class="text-center">View</th>
                                        <th class="text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>

                    <!-- ── TEAM REQUESTS TAB (approvers only) ── -->
                    <?php if ($is_approver): ?>
                    <div class="tab-pane fade"
                         id="tab_team_requests" role="tabpanel">
                        <div class="table-responsive">
                            <table id="wfh_datatable_team"
                                   class="table table-hover table-bordered align-middle w-100">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Staff Name</th>
                                        <th>Department</th>
                                        <th>Date</th>
                                        <th>Day</th>
                                        <th class="text-center">Approval Action</th>
                                        <th class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>

                </div><!-- /.tab-content -->

                <!-- JS context vars -->
                <input type="hidden" id="js_is_approver"
                       value="<?= $is_approver ? '1' : '0' ?>">
                <input type="hidden" id="js_logged_user_id"
                       value="<?= htmlspecialchars($logged_user_id) ?>">
                <input type="hidden" id="js_logged_staff_id"
                       value="<?= htmlspecialchars($logged_staff_id) ?>">

            </div>
        </div>
    </div>
</div>